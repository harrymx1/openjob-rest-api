import companyModel from '../models/companyModel.js';

const companyService = {
  create: async (data, userId) => {
    const { name, location, description } = data;
    return await companyModel.create({ name, location, description, createdBy: userId });
  },
  getAll: async () => companyModel.findAll(),
  getById: async (id) => {
    const company = await companyModel.findById(id);
    if (!company) throw new Error('Company not found');
    return company;
  },
  update: async (id, data, userId) => {
    const existing = await companyModel.findById(id);
    if (!existing) throw new Error('Company not found');
    return await companyModel.update(id, data);
  },
  deleteCompany: async (id) => {
    const existing = await companyModel.findById(id);
    if (!existing) throw new Error('Company not found');
    await companyModel.delete(id);
  }
};

export default companyService;