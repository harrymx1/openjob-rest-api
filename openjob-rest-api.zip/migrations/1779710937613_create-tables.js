/**
 * @type {import('node-pg-migrate').ColumnDefinitions | undefined}
 */
export const shorthands = undefined;

/**
 * @param pgm {import('node-pg-migrate').MigrationBuilder}
 * @param run {() => void | undefined}
 * @returns {Promise<void> | void}
 */
export const up = (pgm) => {
  // 1. Tabel users (dengan unique constraint email)
  pgm.createTable('users', {
    id: { type: 'uuid', default: pgm.func('gen_random_uuid()'), primaryKey: true },
    name: { type: 'varchar(255)', notNull: true },
    email: { type: 'varchar(255)', notNull: true, unique: true },
    password: { type: 'varchar(255)', notNull: true },
    role: { type: 'varchar(50)', notNull: true, default: 'user' },
    created_at: { type: 'timestamp', default: pgm.func('current_timestamp') },
    updated_at: { type: 'timestamp', default: pgm.func('current_timestamp') }
  });

  // 2. Tabel companies
  pgm.createTable('companies', {
    id: { type: 'uuid', default: pgm.func('gen_random_uuid()'), primaryKey: true },
    name: { type: 'varchar(255)', notNull: true },
    location: { type: 'text' },
    description: { type: 'text' },
    created_by: { type: 'uuid', references: 'users(id)', onDelete: 'SET NULL' },
    created_at: { type: 'timestamp', default: pgm.func('current_timestamp') },
    updated_at: { type: 'timestamp', default: pgm.func('current_timestamp') }
  });

  // 3. Tabel categories
  pgm.createTable('categories', {
    id: { type: 'uuid', default: pgm.func('gen_random_uuid()'), primaryKey: true },
    name: { type: 'varchar(255)', notNull: true },
    created_at: { type: 'timestamp', default: pgm.func('current_timestamp') },
    updated_at: { type: 'timestamp', default: pgm.func('current_timestamp') }
  });

  // 4. Tabel jobs
  pgm.createTable('jobs', {
    id: { type: 'uuid', default: pgm.func('gen_random_uuid()'), primaryKey: true },
    company_id: { type: 'uuid', references: 'companies(id)', onDelete: 'CASCADE', notNull: true },
    category_id: { type: 'uuid', references: 'categories(id)', onDelete: 'SET NULL' },
    title: { type: 'varchar(255)', notNull: true },
    description: { type: 'text' },
    job_type: { type: 'varchar(50)' },
    experience_level: { type: 'varchar(50)' },
    location_type: { type: 'varchar(50)' },
    location_city: { type: 'varchar(100)' },
    salary_min: { type: 'bigint' },
    salary_max: { type: 'bigint' },
    is_salary_visible: { type: 'boolean', default: false },
    status: { type: 'varchar(20)', default: 'open' },
    created_by: { type: 'uuid', references: 'users(id)', onDelete: 'SET NULL' },
    created_at: { type: 'timestamp', default: pgm.func('current_timestamp') },
    updated_at: { type: 'timestamp', default: pgm.func('current_timestamp') }
  });

  // 5. Tabel applications
  pgm.createTable('applications', {
    id: { type: 'uuid', default: pgm.func('gen_random_uuid()'), primaryKey: true },
    user_id: { type: 'uuid', references: 'users(id)', onDelete: 'CASCADE', notNull: true },
    job_id: { type: 'uuid', references: 'jobs(id)', onDelete: 'CASCADE', notNull: true },
    status: { type: 'varchar(20)', default: 'pending' },
    applied_at: { type: 'timestamp', default: pgm.func('current_timestamp') },
    updated_at: { type: 'timestamp', default: pgm.func('current_timestamp') }
  });

  // 6. Tabel bookmarks
  pgm.createTable('bookmarks', {
    id: { type: 'uuid', default: pgm.func('gen_random_uuid()'), primaryKey: true },
    user_id: { type: 'uuid', references: 'users(id)', onDelete: 'CASCADE', notNull: true },
    job_id: { type: 'uuid', references: 'jobs(id)', onDelete: 'CASCADE', notNull: true },
    created_at: { type: 'timestamp', default: pgm.func('current_timestamp') }
  });

  // 7. Tabel documents
  pgm.createTable('documents', {
    id: { type: 'uuid', default: pgm.func('gen_random_uuid()'), primaryKey: true },
    user_id: { type: 'uuid', references: 'users(id)', onDelete: 'CASCADE', notNull: true },
    file_name: { type: 'varchar(255)', notNull: true },
    file_url: { type: 'text', notNull: true },
    file_type: { type: 'varchar(100)' },
    uploaded_at: { type: 'timestamp', default: pgm.func('current_timestamp') }
  });

  // 8. Tabel refresh_tokens
  pgm.createTable('refresh_tokens', {
    id: { type: 'uuid', default: pgm.func('gen_random_uuid()'), primaryKey: true },
    user_id: { type: 'uuid', references: 'users(id)', onDelete: 'CASCADE', notNull: true },
    token: { type: 'text', notNull: true },
    expires_at: { type: 'timestamp', notNull: true },
    created_at: { type: 'timestamp', default: pgm.func('current_timestamp') }
  });
};

/**
 * @param pgm {import('node-pg-migrate').MigrationBuilder}
 * @param run {() => void | undefined}
 * @returns {Promise<void> | void}
 */
export const down = (pgm) => {
  pgm.dropTable('refresh_tokens');
  pgm.dropTable('documents');
  pgm.dropTable('bookmarks');
  pgm.dropTable('applications');
  pgm.dropTable('jobs');
  pgm.dropTable('categories');
  pgm.dropTable('companies');
  pgm.dropTable('users');
};
